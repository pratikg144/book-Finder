import React from 'react';
import CoverSlider from './CoverSlider';

export default function DetailsPanel({ book, onClose, onToggleFav, isFav }){
  if(!book) return <div className="p-4 text-gray-400">Select a book to view details</div>;
  return (
    <div className="p-4 bg-glass rounded-xl border border-gray-700">
      <div className="flex gap-4">
        <div className="w-28 h-40 bg-gray-800 rounded-md overflow-hidden"><img src={book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` : '/no-cover.png'} alt={book.title} className="w-full h-full object-cover" /></div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold">{book.title}</h3>
          <p className="text-sm text-gray-300">{book.author_name}</p>
          <p className="text-xs text-gray-400 mt-2">First: {book.first_publish_year}</p>
        </div>
      </div>

      <div className="mt-4">
        <CoverSlider images={(book.images||[]).map((s,i)=>({src:s,alt:`${book.title} ${i+1}`}))} />
      </div>

      <div className="mt-4 flex gap-2">
        <button onClick={()=>onToggleFav(book)} className="bg-gold px-4 py-2 rounded-md">{isFav? 'Remove':'Save'}</button>
        <button onClick={onClose} className="bg-[#0f1113] px-3 py-2 rounded-md">Close</button>
      </div>
    </div>
  )
}
