import React from 'react';
export default function FavoritesList({ favorites, onView, onRemove }){
  if(!favorites.length) return <div className="text-sm text-gray-400">No favorites yet</div>;
  return (
    <ul className="space-y-2">
      {favorites.map(f=>(
        <li key={f.key} className="flex items-center justify-between">
          <div>
            <div className="text-sm">{f.title}</div>
            <div className="text-xs text-gray-400">{f.author_name}</div>
          </div>
          <div className="flex gap-2">
            <button onClick={()=>onView(f)} className="px-2 py-1 bg-[#0f1113] rounded-md">View</button>
            <button onClick={()=>onRemove(f)} className="px-2 py-1 bg-red-600 rounded-md">Remove</button>
          </div>
        </li>
      ))}
    </ul>
  );
}
