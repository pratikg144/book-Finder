        import React, { useEffect, useRef, useState } from 'react';
        export default function CoverSlider({ images = [], initialIndex = 0, onIndexChange }){
  const [index,setIndex]=useState(initialIndex||0);
  const thumbsRef = useRef(null);
  useEffect(()=>{ if(onIndexChange) onIndexChange(index); },[index]);
  useEffect(()=>{ const h=(e)=>{ if(e.key==='ArrowLeft') setIndex(i=>Math.max(0,i-1)); if(e.key==='ArrowRight') setIndex(i=>Math.min(images.length-1,i+1)); }; window.addEventListener('keydown',h); return ()=>window.removeEventListener('keydown',h); },[images]);
  useEffect(()=>{ if(!thumbsRef.current) return; const active = thumbsRef.current.querySelector(`[data-idx="${index}"]`); if(active){ const sc=thumbsRef.current; const rect=active.getBoundingClientRect(); const sr=sc.getBoundingClientRect(); if(rect.left<sr.left||rect.right>sr.right) sc.scrollBy({left:rect.left-sr.left-sr.width/2+rect.width/2,behavior:'smooth'}); } },[index,images]);

  if(!images||images.length===0) return <div className="py-6 text-center text-gray-400">No images</div>;
  return (
    <div className="w-full">
      <div className="relative bg-[#0b0b0c] rounded-md h-56 sm:h-72 flex items-center justify-center overflow-hidden">
        <button onClick={()=>setIndex(i=>Math.max(0,i-1))} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/10 p-2 rounded-full">‹</button>
        <img src={images[index].src} alt={images[index].alt||`cover ${index+1}`} className="max-h-full max-w-full object-contain" />
        <button onClick={()=>setIndex(i=>Math.min(images.length-1,i+1))} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/10 p-2 rounded-full">›</button>
      </div>
      <div ref={thumbsRef} className="mt-3 flex gap-3 overflow-x-auto py-2 slider-scroll">
        {images.map((img,i)=>(
          <button key={i} data-idx={i} onClick={()=>setIndex(i)} className={`flex-shrink-0 w-20 h-28 rounded-md overflow-hidden border ${i===index?'ring-2 ring-gold/60':'border-gray-700'}`}><img src={img.src} alt={img.alt||`thumb ${i+1}`} className="w-full h-full object-cover"/></button>
        ))}
      </div>
    </div>
  );
}
