import React, { useEffect, useState } from 'react';
import { getNYTList } from '../api/nytimes';

export default function FeaturedStrip() {
  const [items, setItems] = useState([]);

  useEffect(()=>{
    (async()=>{
      try{
        const res = await getNYTList('hardcover-fiction');
        const books = res?.results?.books?.slice(0,10) || [];
        setItems(books);
      }catch(e){setItems([])}
    })();
  },[]);

  if (!items.length) return null;

  return (
    <div className="mt-6">
      <h3 className="text-sm text-gray-300 mb-3">Featured</h3>
      <div className="flex gap-3 overflow-x-auto py-2">
        {items.map((b,i)=> (
          <div key={i} className="min-w-[160px] bg-[#0d0e10] p-3 rounded-lg border border-gray-800">
            <div className="h-28 bg-gray-800 mb-2 flex items-center justify-center">
              <img src={b.book_image || ''} alt={b.title} className="h-full object-contain" />
            </div>
            <div className="text-sm font-semibold">{b.title}</div>
            <div className="text-xs text-gray-400">{b.author}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
