import React, { useState, useEffect } from 'react';
import { searchOpenLibrary } from '../api/openLibrary';

export default function SearchPanel({ query, setQuery, onSubmit }) {
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    if (!query || query.length < 2) return setSuggestions([]);
    const t = setTimeout(async () => {
      try {
        const data = await searchOpenLibrary(query, 1);
        const docs = (data.docs || []).slice(0, 6).map((d) => ({ title: d.title, author: d.author_name?.[0] }));
        setSuggestions(docs);
      } catch (e) {
        setSuggestions([]);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="relative">
        <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search books, authors, categories..." className="w-full rounded-full px-5 py-3 bg-[#0f1113] border border-gray-700 focus:ring-2 focus:ring-gold/30 outline-none" />
        <button onClick={onSubmit} className="absolute right-2 top-1/2 -translate-y-1/2 bg-gold px-4 py-2 rounded-full">Search</button>
      </div>

      {suggestions.length > 0 && (
        <div className="mt-3 bg-[#0d0e10] p-3 rounded-lg border border-gray-800">
          {suggestions.map((s,i)=>(
            <div key={i} className="py-2 text-sm text-gray-300">{s.title} <span className="text-xs text-gray-500">— {s.author}</span></div>
          ))}
        </div>
      )}
    </div>
  );
}
