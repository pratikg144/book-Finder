import React from 'react';

export default function GalleryGrid({ books, onSelect, onToggleFav, favorites }){
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {books.map((b)=> (
        <article key={b.key} className="group bg-[#0d0e10] rounded-xl overflow-hidden border border-gray-800 cursor-pointer hover:shadow-[0_10px_30px_rgba(245,215,110,0.08)] transition" onClick={()=>onSelect(b)}>
          <div className="w-full h-64 bg-gray-800 flex items-center justify-center overflow-hidden">
            <img src={b.cover_i ? `https://covers.openlibrary.org/b/id/${b.cover_i}-L.jpg` : '/no-cover.png'} alt={b.title} className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" />
          </div>
          <div className="p-3">
            <h4 className="text-sm font-semibold line-clamp-2">{b.title}</h4>
            <div className="text-xs text-gray-400">{b.author_name}</div>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-xs text-gray-400">{b.first_publish_year}</span>
              <button onClick={(e)=>{e.stopPropagation(); onToggleFav(b)}} className="text-xs bg-black/20 px-2 py-1 rounded-md">{favorites.some(f=>f.key===b.key)?'★':'☆'}</button>
            </div>
          </div>
        </article>
      ))}
    </div>
  )
}
