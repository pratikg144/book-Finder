import React from 'react';
import { motion } from 'framer-motion';

export default function KidsMode({ books, onSelect }){
  return (
    <div className="py-6">
      <h3 className="text-lg font-bold">Kids Picks</h3>
      <div className="mt-4 flex gap-4 overflow-x-auto py-3">
        {books.map((b,i)=> (
          <motion.div key={b.key} whileHover={{ scale: 1.05, rotate: 2 }} className="min-w-[180px] bg-[#fff1e0] p-3 rounded-lg cursor-pointer" onClick={()=>onSelect(b)}>
            <div className="h-40 bg-white rounded-md overflow-hidden mb-2"><img src={b.cover_i?`https://covers.openlibrary.org/b/id/${b.cover_i}-M.jpg`:'/no-cover.png'} alt={b.title} className="w-full h-full object-cover"/></div>
            <div className="text-sm font-semibold text-black">{b.title}</div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
