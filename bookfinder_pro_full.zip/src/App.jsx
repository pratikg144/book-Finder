import React, { useEffect, useRef, useState } from 'react';
import SearchPanel from './components/SearchPanel';
import FeaturedStrip from './components/FeaturedStrip';
import GalleryGrid from './components/GalleryGrid';
import DetailsPanel from './components/DetailsPanel';
import FavoritesList from './components/FavoritesList';
import KidsMode from './components/KidsMode';
import { searchOpenLibrary, getWork } from './api/openLibrary';
import { searchGoogleBooks } from './api/googleBooks';
import './index.css';

export default function App(){
  const [query,setQuery]=useState('');
  const [books,setBooks]=useState([]);
  const [page,setPage]=useState(1);
  const [selected,setSelected]=useState(null);
  const [favorites,setFavorites]=useState(()=>{ try{ return JSON.parse(localStorage.getItem('bf_favs'))||[] }catch{return []} });
  const [isKids,setIsKids]=useState(false);
  const [isLoading,setIsLoading]=useState(false);
  const controllerRef=useRef(null);

  useEffect(()=>{ localStorage.setItem('bf_favs', JSON.stringify(favorites)); },[favorites]);

  // debounce search
  useEffect(()=>{
    const t=setTimeout(()=>{
      if(!query) return setBooks([]);
      setPage(1);
      fetchBooks(query,1);
    },420);
    return ()=>clearTimeout(t);
  },[query]);

  async function fetchBooks(q,p=1){
    setIsLoading(true);
    if(controllerRef.current) controllerRef.current.abort();
    controllerRef.current=new AbortController();
    try{
      const data=await searchOpenLibrary(q,p);
      const docs=(data.docs||[]).slice(0,40).map(d=>({ key:d.key, title:d.title, author_name: d.author_name?.join(', '), first_publish_year: d.first_publish_year, cover_i: d.cover_i, edition_key: d.edition_key, subject: d.subject }));
      setBooks(docs);
    }catch(err){ console.error(err); }
    setIsLoading(false);
  }

  const handleSelect = async (b)=>{
    setSelected(b);
    // try to enrich via works or google books
    try{
      if(b.key?.startsWith('/works/')){
        const id=b.key.replace('/works/','').replace('/','');
        const w=await getWork(id);
        const covers=(w.covers||[]).map(c=>`https://covers.openlibrary.org/b/id/${c}-L.jpg`);
        setSelected(s=>({...s, images: covers, subject: w.subjects?.slice(0,6)||s.subject}));
        return;
      }
      // google books enrich (best-effort)
      const g = await searchGoogleBooks(b.title);
      if(g && g.items && g.items.length){
        const vol = g.items[0].volumeInfo;
        const imgs = vol.imageLinks ? [vol.imageLinks.small, vol.imageLinks.thumbnail, vol.imageLinks.smallThumbnail].filter(Boolean) : [];
        setSelected(s=>({...s, images: imgs, description: vol.description, rating: vol.averageRating}));
      }
    }catch(e){ console.error(e); }
  };

  return (
    <div className="min-h-screen bg-hero-pattern text-white">
      {/* Header */}
      <header className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold">BookFinder Pro</h1>
          <p className="text-sm text-gray-300">Professional book discovery</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={isKids} onChange={()=>setIsKids(k=>!k)} /> Kids mode</label>
          <button onClick={()=>{ setSelected(null); setBooks([]); setQuery(''); }} className="px-3 py-2 bg-[#0f1113] rounded-md">Reset</button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pb-12">
        <SearchPanel query={query} setQuery={setQuery} onSubmit={()=>fetchBooks(query,1)} />
        <FeaturedStrip />

        <div className="mt-8 grid grid-cols-1 lg:grid-cols-4 gap-6">
          <section className="lg:col-span-3">
            {isKids ? <KidsMode books={books.slice(0,12)} onSelect={handleSelect} /> : (
              <>
                {isLoading && <div className="text-sm text-gray-300 mb-3">Loading…</div>}
                <GalleryGrid books={books} onSelect={handleSelect} onToggleFav={(b)=>setFavorites(f=>f.some(x=>x.key===b.key)?f.filter(x=>x.key!==b.key):[b,...f])} favorites={favorites} />
              </>
            )}

            <div className="mt-6 flex justify-center">
              <button onClick={()=>setPage(p=>p+1)} className="px-4 py-2 bg-[#0f1113] rounded-md">Load more</button>
            </div>
          </section>

          <aside className="lg:col-span-1 space-y-6">
            <div className="bg-glass p-4 rounded-xl border border-gray-700">
              <h4 className="text-sm font-semibold mb-2">Book Details</h4>
              <DetailsPanel book={selected} onClose={()=>setSelected(null)} onToggleFav={(b)=>setFavorites(f=>f.some(x=>x.key===b.key)?f.filter(x=>x.key!==b.key):[b,...f])} isFav={favorites.some(x=>x.key===selected?.key)} />
            </div>

            <div className="bg-[#0d0e10] p-4 rounded-xl border border-gray-800">
              <h4 className="text-sm font-semibold mb-3">Favorites</h4>
              <FavoritesList favorites={favorites} onView={(b)=>handleSelect(b)} onRemove={(b)=>setFavorites(f=>f.filter(x=>x.key!==b.key))} />
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
