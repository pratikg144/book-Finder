const NY_KEY = import.meta.env.VITE_NYTIMES_KEY;

export async function getNYTLists() {
  if (!NY_KEY) return null;
  const url = `https://api.nytimes.com/svc/books/v3/lists/names.json?api-key=${NY_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('NYTimes lists fetch failed');
  return res.json();
}

export async function getNYTList(listName) {
  if (!NY_KEY) return null;
  const url = `https://api.nytimes.com/svc/books/v3/lists/current/${encodeURIComponent(listName)}.json?api-key=${NY_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('NYTimes list failed');
  return res.json();
}
