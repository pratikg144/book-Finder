export async function searchOpenLibrary(title, page = 1) {
  const url = `https://openlibrary.org/search.json?title=${encodeURIComponent(title)}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('OpenLibrary search failed');
  return res.json();
}

export async function getWork(workId) {
  const res = await fetch(`https://openlibrary.org/works/${workId}.json`);
  if (!res.ok) throw new Error('OpenLibrary work fetch failed');
  return res.json();
}

export function coverUrl(id, size = 'L') {
  return `https://covers.openlibrary.org/b/id/${id}-${size}.jpg`;
}
