const KEY = import.meta.env.VITE_GOOGLE_BOOKS_KEY;

export async function searchGoogleBooks(title, maxResults = 5) {
  if (!KEY) return null;
  const url = `https://www.googleapis.com/books/v1/volumes?q=intitle:${encodeURIComponent(title)}&maxResults=${maxResults}&key=${KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Google Books search failed');
  return res.json();
}

export async function getGoogleVolume(id) {
  if (!KEY) return null;
  const url = `https://www.googleapis.com/books/v1/volumes/${id}?key=${KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Google volume fetch failed');
  return res.json();
}
